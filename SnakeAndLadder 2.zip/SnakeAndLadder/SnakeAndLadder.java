import java.util.HashMap;
import java.util.Scanner;
import java.util.Random;

public class SnakeAndLadder {
    // ANSI Escape Codes for colors
    public static final String RESET = "\033[0m";
    public static final String RED = "\033[0;31m";
    public static final String GREEN = "\033[0;32m";
    public static final String YELLOW = "\033[0;33m";
    public static final String BLUE = "\033[0;34m";
    public static final String CYAN = "\033[0;36m";
    public static final String WHITE_BG = "\033[47m";
    
    private HashMap<Integer, Integer> snakes;
    private HashMap<Integer, Integer> ladders;
    private Player[] players;
    private Scanner scanner;
    private Random random;
    
    public SnakeAndLadder() {
        initializeGame();
        scanner = new Scanner(System.in);
        random = new Random();
    }
    
    private void initializeGame() {
        // Initialize snakes (head to tail)
        snakes = new HashMap<>();
        snakes.put(99, 5);
        snakes.put(87, 24);
        snakes.put(62, 19);
        snakes.put(54, 34);
        snakes.put(17, 7);
        
        // Initialize ladders (bottom to top)
        ladders = new HashMap<>();
        ladders.put(2, 23);
        ladders.put(6, 45);
        ladders.put(20, 59);
        ladders.put(35, 76);
        ladders.put(50, 88);
        
        // Initialize players
        players = new Player[2];
        players[0] = new Player("Player 1", CYAN);
        players[1] = new Player("Player 2", YELLOW);
    }
    
    private void printDice(int number) {
        String[] diceFaces = {
            "+-------+\n|       |\n|   ●   |\n|       |\n+-------+",
            "+-------+\n| ●     |\n|       |\n|     ● |\n+-------+",
            "+-------+\n| ●     |\n|   ●   |\n|     ● |\n+-------+",
            "+-------+\n| ●   ● |\n|       |\n| ●   ● |\n+-------+",
            "+-------+\n| ●   ● |\n|   ●   |\n| ●   ● |\n+-------+",
            "+-------+\n| ●   ● |\n| ●   ● |\n| ●   ● |\n+-------+"
        };
        
        System.out.println(GREEN + diceFaces[number - 1] + RESET);
    }
    
    private void play() {
        System.out.println(RED + "SNAKES AND LADDERS GAME!" + RESET);
        System.out.println(GREEN + "Ladders: " + ladders + RESET);
        System.out.println(RED + "Snakes: " + snakes + RESET);
        
        int currentPlayer = 0;
        while (true) {
            Player player = players[currentPlayer];
            System.out.printf("\n%s%s's turn (Press Enter to roll dice)%s", 
                player.getColor(), player.getName(), RESET);
            scanner.nextLine();
            
            int dice = random.nextInt(6) + 1;
            System.out.println(WHITE_BG + GREEN + "Dice Rolled: " + dice + RESET);
            printDice(dice);
            
            int newPosition = player.getPosition() + dice;
            if (newPosition > 100) {
                System.out.println("Can't move! Need exact number to win.");
                currentPlayer = (currentPlayer + 1) % 2;
                continue;
            }
            
            player.setPosition(newPosition);
            System.out.printf("%sNew position: %d%s\n", 
                player.getColor(), newPosition, RESET);
            
            if (checkSnakeOrLadder(player)) {
                System.out.printf("%sPosition after snake/ladder: %d%s\n",
                    player.getColor(), player.getPosition(), RESET);
            }
            
            displayScores();
            
            if (player.getPosition() == 100) {
                System.out.printf("\n%s%s WINS THE GAME!!!%s\n", 
                    player.getColor(), player.getName(), RESET);
                break;
            }
            
            currentPlayer = (currentPlayer + 1) % 2;
        }
    }
    
    private boolean checkSnakeOrLadder(Player player) {
        int position = player.getPosition();
        
        if (snakes.containsKey(position)) {
            int newPosition = snakes.get(position);
            player.setPosition(newPosition);
            System.out.printf(RED + "Oops! Snake bite from %d to %d%s\n",
                position, newPosition, RESET);
            return true;
        }
        
        if (ladders.containsKey(position)) {
            int newPosition = ladders.get(position);
            player.setPosition(newPosition);
            System.out.printf(GREEN + "Yay! Climbed ladder from %d to %d%s\n",
                position, newPosition, RESET);
            return true;
        }
        
        return false;
    }
    
    private void displayScores() {
        System.out.println("\nCurrent Scores:");
        for (Player player : players) {
            System.out.printf("%s%s: %d%s\n", 
                player.getColor(), player.getName(), player.getPosition(), RESET);
        }
    }
    
    public static void main(String[] args) {
        new SnakeAndLadder().play();
    }
    
    private class Player {
        private String name;
        private int position;
        private String color;
        
        public Player(String name, String color) {
            this.name = name;
            this.position = 0;
            this.color = color;
        }
        
        public String getName() { return name; }
        public int getPosition() { return position; }
        public void setPosition(int position) { this.position = position; }
        public String getColor() { return color; }
    }
}